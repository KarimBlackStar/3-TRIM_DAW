package daw.cotarelo.model;

import java.util.List;

/**
 *
 * @author fperez
 */
public class GestionSistema {

    List<Object> usuario;// atributo: colección de datos

    private final String[][] usuarios;
    private final int MAX_FILAS = 5;
    private final int MAX_COLUMNAS = 16;

    //Inicializamos la matriz con el tamaño requerido(creamos la tabla vacia)
    public GestionSistema() {
        this.usuarios = new String[MAX_FILAS][MAX_COLUMNAS];
    }

    //Array 2D
    public String[][] getUsuarios() {
        return usuarios;
    }

    public int getMAX_FILAS() {
        return MAX_FILAS;
    }

    public int getMAX_COLUMNAS() {
        return MAX_COLUMNAS;
    }

    /**
     *
     * @param p
     */
    public int agregarUsuario(String nif) {
        boolean registrado = false;
        int filas = 0;
        int filaAsignada = -1;

        while (!registrado && filas < MAX_FILAS) {
            if (usuarios[filas][0] == null || usuarios[filas][0].isEmpty()) {
                usuarios[filas][0] = nif.toUpperCase();
                filaAsignada = filas;
                registrado = true;
            }
            filas++;
        }
        return filaAsignada;
    }

    public boolean nifExistente(String nif) {
        boolean existe = false;
        int fila = 0;

        while (!existe && fila < MAX_FILAS) {
            if (usuarios[fila][0] != null && usuarios[fila][0].equalsIgnoreCase(nif)) {
                existe = true;
            }
            fila++;
        }
        return existe;
    }
}
