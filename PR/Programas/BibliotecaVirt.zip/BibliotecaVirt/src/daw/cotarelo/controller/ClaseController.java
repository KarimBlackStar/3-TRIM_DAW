package daw.cotarelo.controller;

import daw.cotarelo.model.GestionSistema;
import daw.cotarelo.view.ClaseView;

/**
 *
 * @author fperez
 */
public class ClaseController {

    private ClaseView vista;
    private GestionSistema modelo;

    /**
     *
     * @param vista
     * @param modelo
     */
    public ClaseController(ClaseView vista, GestionSistema modelo) {
        this.vista = vista;
        this.modelo = modelo;
    }

    /**
     *
     */
    public int registrarUsuario(String nif) {
        int filaDestino = -1;
        int maxFilas = modelo.getMAX_FILAS();

        vista.pedirDNI();
        if (modelo.nifExistente(nif)) {
            vista.mostrarError("El usuario con NIF: " + nif + "ya está registrado");
        }
        filaDestino = modelo.agregarUsuario(nif);

        if (filaDestino == -1) {
            vista.mostrarError("No puede haber más de " + maxFilas + "usuarios registrados");
        }
        return filaDestino;
    }

    /**
     *
     */
    public void prestamo() {
        // pedir el dato necesario
        // buscar el elemento
        // mostrar Elemento
    }

    /**
     * Plantilla
     */
    public void devolucion() {
        // formatearlo como sea necesario
        for (Object o : modelo.getUsuarios()) {
            vista.mostrarMensaje(o.toString() + "\n");
        }
    }

    /**
     *
     */
    public void historial() {
        // pedir dato
        // usar método historial
    }

    public void reiniciarSistema() {
    }

}
