package com.daw.view;

import java.util.Scanner;

public class Vista {

    // Muestra el menú de la asociación
    public void mostrarMenu() {
        System.out.println("\n--- MENÚ ASOCIACIÓN ---");
        System.out.println("1. Agregar socio");
        System.out.println("2. Buscar socio");
        System.out.println("3. Pagar trimestre");
        System.out.println("4. Mostrar todos los socios");
        System.out.println("5. Salir");
        System.out.print("Elige una de las opciones del menú: ");
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    public void mostrarError(String mensaje) {
        System.err.println(mensaje);
    }

    public String pedirTexto(String mensaje, Scanner sc) {
        System.out.print(mensaje);
        String texto = sc.nextLine();
        return texto;
    }

    public int pedirNumero(String mensaje, Scanner sc) {
        System.out.print(mensaje);
        int numero = -1;
        if (sc.hasNextInt()) {
            numero = sc.nextInt();
            sc.nextLine();
        } else {
            sc.nextLine();
        }
        return numero;
    }
}
