package com.daw.modelo;

public class GestionAsociacion {

    public static final int TAMANO = 100;
    public static final double PRECIO_TRIMESTRE = 50.0;

    private Socio[] club = new Socio[TAMANO];
    private int contadorSocios = 0;

    public Socio[] getClub() {
        return this.club;
    }

    public int getContadorSocios() {
        return this.contadorSocios;
    }

    // Registra un socio si queda espacio en el array
    public boolean registrarSocio(Socio nuevo) {
        boolean exito = false;
        if (contadorSocios < TAMANO) {
            club[contadorSocios] = nuevo;
            contadorSocios++;
            exito = true;
        }
        return exito;
    }

    // Busca un socio por su carnet mediante un bucle tradicional
    public Socio buscarSocioPorCarnet(String carnet) {
        Socio encontrado = null;
        int i = 0;
        while (i < contadorSocios && encontrado == null) {
            if (club[i] != null && club[i].getNumeroCarnet().equals(carnet)) {
                encontrado = club[i];
            }
            i++;
        }
        return encontrado;
    }
}
