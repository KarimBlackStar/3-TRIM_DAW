package com.daw.modelo;

public class Socio {

    private String nombre;
    private String numeroCarnet;
    private double pagoTrim1;
    private double pagoTrim2;
    private double pagoTrim3;
    private double pagoTrim4;

    // Constructor con parámetros que inicializa los pagos a -1
    public Socio(String nombre, String numeroCarnet) {
        this.nombre = nombre;
        this.numeroCarnet = numeroCarnet;
        this.pagoTrim1 = -1;
        this.pagoTrim2 = -1;
        this.pagoTrim3 = -1;
        this.pagoTrim4 = -1;
    }

    // Constructor vacío que también inicializa los pagos por defecto
    public Socio() {
        this.pagoTrim1 = -1;
        this.pagoTrim2 = -1;
        this.pagoTrim3 = -1;
        this.pagoTrim4 = -1;
    }

    // --- GETTERS Y SETTERS ---
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNumeroCarnet() {
        return numeroCarnet;
    }

    public void setNumeroCarnet(String numeroCarnet) {
        this.numeroCarnet = numeroCarnet;
    }

    public double getPagoTrim1() {
        return pagoTrim1;
    }

    public void setPagoTrim1(double pagoTrim1) {
        this.pagoTrim1 = pagoTrim1;
    }

    public double getPagoTrim2() {
        return pagoTrim2;
    }

    public void setPagoTrim2(double pagoTrim2) {
        this.pagoTrim2 = pagoTrim2;
    }

    public double getPagoTrim3() {
        return pagoTrim3;
    }

    public void setPagoTrim3(double pagoTrim3) {
        this.pagoTrim3 = pagoTrim3;
    }

    public double getPagoTrim4() {
        return pagoTrim4;
    }

    public void setPagoTrim4(double pagoTrim4) {
        this.pagoTrim4 = pagoTrim4;
    }

    // Calcula la suma de los trimestres pagados saltándose los que valen -1
    public double calcularPagosTotales() {
        double total = 0;
        if (pagoTrim1 != -1) {
            total += pagoTrim1;
        }
        if (pagoTrim2 != -1) {
            total += pagoTrim2;
        }
        if (pagoTrim3 != -1) {
            total += pagoTrim3;
        }
        if (pagoTrim4 != -1) {
            total += pagoTrim4;
        }
        return total;
    }

    // Cuenta cuántos trimestres tienen un valor distinto a -1
    public int trimestresPagados() {
        int contador = 0;
        if (pagoTrim1 != -1) {
            contador++;
        }
        if (pagoTrim2 != -1) {
            contador++;
        }
        if (pagoTrim3 != -1) {
            contador++;
        }
        if (pagoTrim4 != -1) {
            contador++;
        }
        return contador;
    }

    // Representación en texto del socio
    @Override
    public String toString() {
        String info = "Socio: " + nombre + " | Carnet: " + numeroCarnet;
        return info;
    }
}
