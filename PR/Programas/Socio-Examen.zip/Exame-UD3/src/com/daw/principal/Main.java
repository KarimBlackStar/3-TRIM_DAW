package com.daw.principal;

import com.daw.controlador.Controlador;
import com.daw.modelo.GestionAsociacion;
import com.daw.view.Vista;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        GestionAsociacion modelo = new GestionAsociacion();
        Vista vista = new Vista();
        Controlador controller = new Controlador(vista, modelo);

        Scanner miScanner = new Scanner(System.in);
        int opcion = 0;
        boolean salir = false;

        do {
            try {
                vista.mostrarMenu();
                if (miScanner.hasNextInt()) {
                    opcion = miScanner.nextInt();
                    miScanner.nextLine(); // Limpiar el buffer
                } else {
                    miScanner.nextLine();
                    throw new InputMismatchException();
                }

                switch (opcion) {
                    case 1:
                        controller.agregarSocio();
                        break;
                    case 2:
                        controller.buscarSocio();
                        break;
                    case 3:
                        controller.pagarTrimestre();
                        break;
                    case 4:
                        controller.mostrarTodos();
                        break;
                    case 5:
                        vista.mostrarMensaje("¡¡Hasta pronto!!");
                        salir = true;
                        break;
                    default:
                        vista.mostrarError("ERROR: El número debe estar entre 1 y 5.");
                        break;
                }
            } catch (InputMismatchException e) {
                vista.mostrarError("ERROR: Tienes que introducir un número. Vuelve a intentarlo.");
            }
        } while (!salir);

        miScanner.close();
    }
}
