package com.daw.controlador;

import com.daw.modelo.GestionAsociacion;
import com.daw.modelo.Socio;
import com.daw.view.Vista;
import java.util.Scanner;

public class Controlador {

    private Vista vista;
    private GestionAsociacion modelo;
    private Scanner sc;

    public Controlador(Vista vista, GestionAsociacion modelo) {
        this.vista = vista;
        this.modelo = modelo;
        this.sc = new Scanner(System.in);
    }

    // Pide los datos de un socio y lo guarda en el modelo
    public void agregarSocio() {
        try {
            String nombre = vista.pedirTexto("Nombre: ", sc);
            String carnet = vista.pedirTexto("Carnet: ", sc);

            if (nombre.trim().isEmpty() || carnet.trim().isEmpty()) {
                throw new IllegalArgumentException("ERROR: El nombre y el carnet no pueden estar vacíos.");
            }

            Socio nuevo = new Socio(nombre, carnet);
            boolean exito = modelo.registrarSocio(nuevo);

            if (exito) {
                vista.mostrarMensaje("Añadido correctamente: " + nuevo.toString());
            } else {
                vista.mostrarMensaje("ERROR: El array de socios está lleno.");
            }
        } catch (IllegalArgumentException e) {
            vista.mostrarError(e.getMessage());
        }
    }

    // Busca un socio y da la opción de pagar trimestres si le falta alguno
    public void buscarSocio() {
        try {
            String carnet = vista.pedirTexto("Introduce el carnet a buscar: ", sc);
            Socio s = modelo.buscarSocioPorCarnet(carnet);

            if (s != null) {
                vista.mostrarMensaje(s.toString());
                vista.mostrarMensaje("Total pagado: " + s.calcularPagosTotales() + "€");

                if (s.trimestresPagados() < 4) {
                    String respuesta = vista.pedirTexto("Faltan pagos. ¿Quieres pagar ahora? (s/n): ", sc);
                    if (respuesta.equalsIgnoreCase("s")) {
                        gestionarPagoDirecto(s);
                    }
                } else {
                    vista.mostrarMensaje("El socio tiene todo pagado.");
                }
            } else {
                vista.mostrarMensaje("Socio no encontrado.");
            }
        } catch (IllegalArgumentException e) {
            vista.mostrarError(e.getMessage());
        }
    }

    // Permite buscar a un usuario directamente para abonar un trimestre
    public void pagarTrimestre() {
        try {
            String carnet = vista.pedirTexto("Carnet para realizar el pago: ", sc);
            Socio s = modelo.buscarSocioPorCarnet(carnet);

            if (s != null) {
                gestionarPagoDirecto(s);
            } else {
                vista.mostrarMensaje("Socio no encontrado.");
            }
        } catch (IllegalArgumentException e) {
            vista.mostrarError(e.getMessage());
        }
    }

    // Lista todos los socios creados hasta el momento
    public void mostrarTodos() {
        Socio[] club = modelo.getClub();
        int total = modelo.getContadorSocios();

        if (total == 0) {
            vista.mostrarMensaje("No hay socios registrados.");
        } else {
            for (int i = 0; i < total; i++) {
                if (club[i] != null) {
                    vista.mostrarMensaje(club[i].toString());
                }
            }
        }
    }

    // Método auxiliar privado para gestionar la asignación de dinero a los trimestres
    private void gestionarPagoDirecto(Socio s) {
        vista.mostrarMensaje("Trimestres pendientes: ");
        if (s.getPagoTrim1() == -1) {
            vista.mostrarMensaje("1. Trimestre 1");
        }
        if (s.getPagoTrim2() == -1) {
            vista.mostrarMensaje("2. Trimestre 2");
        }
        if (s.getPagoTrim3() == -1) {
            vista.mostrarMensaje("3. Trimestre 3");
        }
        if (s.getPagoTrim4() == -1) {
            vista.mostrarMensaje("4. Trimestre 4");
        }

        int tri = vista.pedirNumero("Elige trimestre (1-4): ", sc);

        switch (tri) {
            case 1:
                s.setPagoTrim1(GestionAsociacion.PRECIO_TRIMESTRE);
                break;
            case 2:
                s.setPagoTrim2(GestionAsociacion.PRECIO_TRIMESTRE);
                break;
            case 3:
                s.setPagoTrim3(GestionAsociacion.PRECIO_TRIMESTRE);
                break;
            case 4:
                s.setPagoTrim4(GestionAsociacion.PRECIO_TRIMESTRE);
                break;
            default:
                vista.mostrarMensaje("Opción de trimestre no válida.");
                break;
        }

        vista.mostrarMensaje("Pago realizado. Nuevo total: " + s.calcularPagosTotales() + "€");
    }
}
