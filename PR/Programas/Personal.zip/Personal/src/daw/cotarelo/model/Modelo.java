package daw.cotarelo.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author fperez
 */
public class Modelo {

    List<Persona> lista;// atributo: colección de datos

    /**
     *
     */
    public Modelo() {
        lista = new ArrayList<>();// inicializar el modelo
    }

    // crear método para obtener la colección si es necesario
    public List<Persona> getLista() {
        return lista;
    }

    /**
     *
     * @param p
     */
    public void agregarElemento(Persona p) {
        lista.add(p);
    }

    /**
     *
     * @return
     */
    public boolean eliminarElemento(/*atributos necesarios*/) {
        int i = 0;
        boolean encontrado = false;
        while (!encontrado && i < lista.size()) {
            if (true /*sustituir por la condicion que necesite*/) {
                lista.remove(i);
                encontrado = true;
            }
            i++;
        }
        return encontrado;
    }

    /**
     * Obtiene la descripción de un elemento {@code Persona}.
     *
     * @return La descripción de la persona con DNI {@code pDNI}.
     */
    public String mostrarElemento(/*atributos necesarios*/) {
        StringBuilder str = new StringBuilder();
        for (Object obj : lista) {
            if (true /*sustituir por la condicion que necesite*/) {
                str.append(obj.toString());
            }
        }
        return str.toString();
    }
}
