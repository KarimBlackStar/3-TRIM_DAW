/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daw.cotarelo.model;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

/**
 *
 * @author khanouni
 */
public class Persona {

    private String nome;
    private int edad;

    public Persona(String nome, int edad) {
        this.nome = nome;
        this.edad = edad;
    }

    public int getEdad() {
        return edad;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public String toString() {
        return "Persona{" + "nome=" + nome + ", edad=" + edad + '}';
    }

    public void guardarDatos() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce o nome da persoa: ");
        String nome = sc.nextLine();
        System.out.print("Introduce la edad da persoa: ");
        int edad = sc.nextInt();
        sc.nextLine();
// Creamos o obxecto
        Persona p = new Persona(nome, edad);
// Gardámolo no ficheiro "persoas.dat"
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("persoas.dat"))) {
            oos.writeObject(p);
            System.out.println("Obxecto gardado con éxito.");
        } catch (IOException e) {
            System.out.println("Erro ao gardar: " + e.getMessage());
        }
    }
}
