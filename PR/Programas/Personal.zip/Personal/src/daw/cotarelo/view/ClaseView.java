package daw.cotarelo.view;

import java.util.Scanner;

/**
 * Vista.
 *
 * @author fperez
 */
public class ClaseView {

    private Scanner sc;

    /**
     * Constructor InstitutoVista. Crea un objeto InstitutoVista que inicializa
     * los mecanismos de E/S de datos de la vista.
     */
    public ClaseView() {
        this.sc = new Scanner(System.in);
    }

    /**
     * Pide un número entero al usuario. La descripción del dato númerico se
     * incluye en {@code mensaje}.
     *
     * @param mensaje Descripción de la petición del dato numérico.
     * @return El número entero introducido por el usuario (ya validado).
     */
    public int pedirEntero(String mensaje) {
        int num = 0; // n.º a devolver
        boolean valido = false; // indica la validez del dato introducido por el usuario
        do {
            this.mostrarMensaje(mensaje);
            try {
                num = Integer.parseInt(sc.nextLine());
                valido = true;
            } catch (NumberFormatException e) {
                this.mostrarError(String.format("Tipo de dato introducido "
                        + "incorrecto: %s", e.getMessage()));
            }
        } while (!valido);
        return num;
    }

    /**
     * Pide un número en coma flotante con doble precisión al usuario. La
     * descripción del dato númerico se incluye en {@code mensaje}.
     *
     * @param mensaje Descripción de la petición del dato numérico.
     * @return El número en coma flotante de doble precisión introducido por el
     * usuario (ya validado).
     */
    public double pedirDecimal(String mensaje) {
        double num = 0.0; // n.º a devolver
        boolean valido = false; // indica la validez del dato introducido por el usuario
        do {
            this.mostrarMensaje(mensaje);
            try {
                num = Double.parseDouble(sc.nextLine());
                valido = true;
            } catch (NumberFormatException e) {
                this.mostrarError(String.format("Tipo de dato introducido "
                        + "incorrecto: %s", e.getMessage()));
            }
        } while (!valido);
        return num;
    }

    /**
     * Pide una cadena de texto al usuario. La descripción del dato se incluye
     * en {@code mensaje}.
     *
     * @param mensaje Descripción de la petición de la cadena.
     * @return La cadena introducida por el usuario.
     */
    public String pedirCadena(String mensaje) {
        this.mostrarMensaje(mensaje);
        return sc.nextLine();
    }

    /**
     * Pide un carácter al usuario. La descripción del dato se incluye en
     * {@code mensaje}.
     *
     * @param mensaje Descripción de la petición del carácter.
     * @return El carácter introducido por el usuario.
     */
    public char pedirCaracter(String mensaje) {
        this.mostrarMensaje(mensaje);
        return sc.nextLine().toUpperCase().charAt(0);
    }

    /**
     * Muestra un mensaje de texto.
     *
     * @param mensaje Texto del mensaje que se quiere mostrar.
     */
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    /**
     * Muestra un mensaje de error.
     *
     * @param mensaje Mensaje de error.
     */
    public void mostrarError(String mensaje) {
        System.err.printf("[!] %s%n", mensaje);
    }

    /**
     * Cierra la vista, cerrando los mecanismos de E/S de datos.
     */
    public void cerrar() {
        System.out.println("Hasta la proxima!");
        sc.close();
    }

}
