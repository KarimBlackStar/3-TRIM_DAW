package daw.cotarelo.main;

import daw.cotarelo.controlador.MenuController;
import daw.cotarelo.controller.ClaseController;
import daw.cotarelo.model.Modelo;
import daw.cotarelo.view.ClaseView;
import java.util.InputMismatchException;

/**
 *
 * @author fperez
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // CONFIGURACIÓN DEL MENÚ
        MenuController menu = new MenuController(
                "Gestión de docentes",
                new String[]{
                    "Crear objeto + añadir a la lista",
                    "Filtrar por edad y añadir edad.dat",
                    "Filtrar por edad y guardar edad.csv",
                    "Mostrar edad.dat",
                    "Mostrar edad.csv",
                    "Salir"
                }
        );

        // CONFIGURACIÓN CONTROLADOR(ES)-> InstitutoControlador
        //Persona persona = new Persona(nome, 0);
        Modelo modelo = new Modelo();
        ClaseView vista = new ClaseView();

        ClaseController controller = new ClaseController(vista, modelo);

        // LÓGICA DEL PROGRAMA PRINCIPAL
        int opcion = 0;
        boolean salir = false;

        do {
            try {
                opcion = menu.ejecutar();

                switch (opcion) {
                    case 1 -> { // introducir docente
                        controller.crearObjetoYAñadirLista();
                    }
                    case 2 -> {
                        controller.filtrarEdadYGuardarDAT();
                    }
                    case 3 -> {
                        controller.filtrarEdadYGuardarCSV();
                    }
                    case 4 -> {
                        controller.mostrarEdadCSV();
                    }
                    case 5 -> {
                        controller.mostrarEdadTXT();
                    }
                    case 6 -> {
                        vista.cerrar();
                        menu.salirDelMenu();
                    }
                }
            } catch (IllegalArgumentException e) {
                vista.mostrarError(e.getMessage());
            } catch (InputMismatchException e) {
                vista.mostrarError("Debe introducir un numero.");
            } finally {
                vista.mostrarMensaje("");
            }
        } while (!salir);
    }

}
