package daw.cotarelo.controller;

import daw.cotarelo.model.GestionSistema;
import daw.cotarelo.view.ClaseView;
import java.util.Scanner;

public class ClaseController {

    private ClaseView vista;
    private GestionSistema modelo;
    private Scanner sc;

    public ClaseController(ClaseView vista, GestionSistema modelo) {
        this.vista = vista;
        this.modelo = modelo;
        this.sc = new Scanner(System.in);
    }

    // Registra al usuario controlando el formato del NIF con un try-catch interno
    public void registrarUsuario() {
        try {
            String nif = vista.pedirTexto("Introduce el NIF (8 números y 1 letra): ", sc);
            nif = nif.trim();

            if (nif.isEmpty()) {
                throw new IllegalArgumentException("El campo del NIF no puede estar vacío.");
            }

            nif = nif.toUpperCase();
            if (!nif.matches("^[0-9]{8}[A-Z]$")) {
                throw new IllegalArgumentException("Formato incorrecto. Tienen que ser 8 números y una letra.");
            }

            if (!modelo.validarLetraNif(nif)) {
                throw new IllegalArgumentException("La letra del NIF no se corresponde con el número.");
            }

            modelo.registrarUsuario(nif);
            
        } catch (IllegalArgumentException e) {
            vista.mostrarError(e.getMessage());
        }
    }

    // Gestiona el préstamo controlando que el usuario exista y el libro sea correcto
    public void prestamo() {
        try {
            String nif = vista.pedirTexto("Introduce el NIF del usuario: ", sc).trim().toUpperCase();
            int fila = modelo.buscarFilaUsuario(nif);

            if (fila == -1) {
                throw new IllegalArgumentException("Este usuario no está registrado en el sistema.");
            }

            int slot = modelo.buscarSlotLibre(fila);
            if (slot == -1) {
                vista.mostrarMensaje("Aviso: Este usuario ya tiene el límite de 5 préstamos ocupados.");
            } else {
                vista.mostrarCatalogoLibros(modelo.getCatalogo());
                int seleccion = vista.pedirNumero("Escoge el número del libro (1-10): ", sc) - 1;

                if (seleccion < 0 || seleccion >= 10) {
                    throw new IllegalArgumentException("El número escogido no está en el catálogo.");
                }

                String titulo = modelo.getCatalogo()[seleccion];
                modelo.guardarPrestamo(fila, slot, titulo);
                vista.mostrarMensaje("Préstamo anotado correctamente.");
            }
            
        } catch (IllegalArgumentException e) {
            vista.mostrarError(e.getMessage());
        }
    }

    // Gestiona la devolución controlando la existencia del usuario y el préstamo
    public void devolucion() {
        try {
            String nif = vista.pedirTexto("Introduce el NIF del usuario: ", sc).trim().toUpperCase();
            int fila = modelo.buscarFilaUsuario(nif);

            if (fila == -1) {
                throw new IllegalArgumentException("No se ha encontrado al usuario en el sistema.");
            }

            String idPrestamo = vista.pedirTexto("Introduce el código del préstamo a devolver: ", sc).trim();
            int slot = modelo.buscarSlotPrestamoActivo(fila, idPrestamo);

            if (slot == -1) {
                vista.mostrarMensaje("No consta ningún préstamo activo con ese código.");
            } else {
                int nota = 0;
                do {
                    nota = vista.pedirNumero("Valora el libro (del 1 al 5): ", sc);
                    if (nota < 1 || nota > 5) {
                        vista.mostrarMensaje("Nota incorrecta. Debe ser un número del 1 al 5.");
                    }
                } while (nota < 1 || nota > 5);

                modelo.actualizarValoracion(fila, slot, nota);
                vista.mostrarMensaje("Devolución asentada con éxito.");
            }
            
        } catch (IllegalArgumentException e) {
            vista.mostrarError(e.getMessage());
        }
    }

    // Muestra el historial controlando si el usuario existe
    public void historial() {
        try {
            String nif = vista.pedirTexto("Introduce el NIF del usuario: ", sc).trim().toUpperCase();
            int fila = modelo.buscarFilaUsuario(nif);

            if (fila == -1) {
                throw new IllegalArgumentException("El usuario introducido no existe.");
            }

            int puntos = modelo.calcularPuntosUsuario(fila);
            vista.imprimirHistorial(nif, modelo.getUsuariosPrestamos(), fila, puntos);
            
        } catch (IllegalArgumentException e) {
            vista.mostrarError(e.getMessage());
        }
    }

    // Recoge los títulos y gestiona el reinicio atrapando posibles fallos
    public void reiniciarSistema() {
        try {
            vista.mostrarMensaje("\n--- RESETEO DEL SISTEMA ---");
            String[] nuevosTitulos = new String[10];

            for (int i = 0; i < 10; i++) {
                nuevosTitulos[i] = vista.pedirTexto("Nombre del nuevo libro [" + (i + 1) + "]: ", sc).trim();
            }

            modelo.reiniciarDatosSistema(nuevosTitulos);
            vista.mostrarMensaje("Sistema restablecido y catálogo actualizado.");
            
        } catch (IllegalArgumentException e) {
            vista.mostrarError(e.getMessage());
        }
    }
}