package daw.cotarelo.model;

public class GestionSistema {

    private static final String[] CATALOGO_INICIAL = {
        "Don Quijote", "Cien Años de Soledad", "El Nombre del Viento", "1984", 
        "El Principito", "Harry Potter", "Dune", "Neuromante", 
        "El Señor de los Anillos", "Fundación"
    };
    
    private String[] catalogo = new String[10];
    private String[][] usuariosPrestamos = new String[5][16];
    private int contadorPrestamos = 1; 
    private int totalUsuarios = 0;

    public GestionSistema() {
        for (int i = 0; i < 10; i++) {
            catalogo[i] = CATALOGO_INICIAL[i];
        }
    }

    public String[] getCatalogo() {
        return this.catalogo;
    }

    public String[][] getUsuariosPrestamos() {
        return this.usuariosPrestamos;
    }

    public int getTotalUsuarios() {
        return this.totalUsuarios;
    }

    public boolean validarLetraNif(String nif) {
        boolean resultado = false;
        String parteNumerica = nif.substring(0, 8);
        char letraIntroducida = nif.charAt(8);
        
        int numero = Integer.parseInt(parteNumerica);
        int resto = numero % 23;
        
        String letrasAsignacion = "TRWAGMYFPDXBNJZSQVHLCKE";
        char letraCorrecta = letrasAsignacion.charAt(resto);

        if (letraIntroducida == letraCorrecta) {
            resultado = true;
        }
        
        return resultado;
    }

    public int registrarUsuario(String nif) {
        int i = 0;
        int indiceFila = -1;
        boolean encontrado = false;

        while (i < totalUsuarios && !encontrado) {
            if (usuariosPrestamos[i][0] != null && usuariosPrestamos[i][0].equals(nif)) {
                indiceFila = i;
                encontrado = true;
            }
            i++;
        }

        if (!encontrado) {
            try {
                if (totalUsuarios >= 5) {
                    throw new IllegalArgumentException("La base de datos está llena. Límite de 5 usuarios.");
                }
                usuariosPrestamos[totalUsuarios][0] = nif;
                indiceFila = totalUsuarios;
                totalUsuarios++;
            } catch (IllegalArgumentException e) {
                System.out.println("\n[ERROR MATRIZ]: " + e.getMessage());
            }
        }

        return indiceFila;
    }

    public int buscarFilaUsuario(String nif) {
        int i = 0;
        int fila = -1;
        boolean encontrado = false;

        while (i < totalUsuarios && !encontrado) {
            if (usuariosPrestamos[i][0] != null && usuariosPrestamos[i][0].equals(nif)) {
                fila = i;
                encontrado = true;
            }
            i++;
        }
        return fila;
    }

    public int buscarSlotLibre(int filaUsuario) {
        int i = 0;
        int slot = -1;
        boolean encontrado = false;

        while (i < 5 && !encontrado) {
            int colTitulo = 3 * i + 1;
            if (usuariosPrestamos[filaUsuario][colTitulo] == null || usuariosPrestamos[filaUsuario][colTitulo].isEmpty()) {
                slot = i;
                encontrado = true;
            }
            i++;
        }
        return slot;
    }

    public void guardarPrestamo(int fila, int slot, String titulo) {
        int cTitulo = 3 * slot + 1;
        int cId = 3 * slot + 2;    
        int cVal = 3 * slot + 3;   

        usuariosPrestamos[fila][cTitulo] = titulo;
        usuariosPrestamos[fila][cId] = String.valueOf(contadorPrestamos);
        usuariosPrestamos[fila][cVal] = "PENDIENTE";

        contadorPrestamos++; 
    }

    public int buscarSlotPrestamoActivo(int fila, String idPrestamo) {
        int i = 0;
        int slot = -1;
        boolean encontrado = false;

        while (i < 5 && !encontrado) {
            int colId = 3 * i + 2;  
            int colVal = 3 * i + 3; 
            if (usuariosPrestamos[fila][colId] != null && 
                usuariosPrestamos[fila][colId].equals(idPrestamo) && 
                "PENDIENTE".equals(usuariosPrestamos[fila][colVal])) {
                
                slot = i;
                encontrado = true;
            }
            i++;
        }
        return slot;
    }

    public void actualizarValoracion(int fila, int slot, int nota) {
        int colVal = 3 * slot + 3;
        usuariosPrestamos[fila][colVal] = String.valueOf(nota);
    }

    public int calcularPuntosUsuario(int fila) {
        int puntos = 0;
        for (int i = 0; i < 5; i++) {
            int colVal = 3 * i + 3;
            String val = usuariosPrestamos[fila][colVal];
            if (val != null && !"PENDIENTE".equals(val)) {
                int nota = Integer.parseInt(val);
                if (nota >= 4) {
                    puntos += 10;
                } else if (nota >= 1 && nota <= 3) {
                    puntos += 5;
                }
            }
        }
        return puntos;
    }

    public void reiniciarDatosSistema(String[] nuevosTitulos) {
        for (int i = 0; i < usuariosPrestamos.length; i++) {
            for (int j = 0; j < usuariosPrestamos[i].length; j++) {
                usuariosPrestamos[i][j] = null;
            }
        }
        contadorPrestamos = 1;
        totalUsuarios = 0;

        for (int i = 0; i < 10; i++) {
            try {
                if (nuevosTitulos[i] == null || nuevosTitulos[i].trim().isEmpty()) {
                    throw new IllegalArgumentException("No se permiten nombres vacíos en los libros.");
                }
                String primera = nuevosTitulos[i].substring(0, 1).toUpperCase();
                String resto = nuevosTitulos[i].substring(1).toLowerCase();
                catalogo[i] = primera + resto;
            } catch (IllegalArgumentException e) {
                System.out.println("\n[ERROR REINICIO]: " + e.getMessage());
            }
        }
    }
}