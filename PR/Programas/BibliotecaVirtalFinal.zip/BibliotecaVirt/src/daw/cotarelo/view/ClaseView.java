package daw.cotarelo.view;

import java.util.Scanner;

public class ClaseView {

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    public void mostrarError(String mensaje) {
        System.err.println("\n[ERROR]: " + mensaje);
    }

    public void cerrar() {
        System.out.println("Cerrando los recursos de la biblioteca... ¡Hasta pronto!");
    }

    public String pedirTexto(String mensaje, Scanner sc) {
        System.out.print(mensaje);
        String texto = sc.nextLine();
        return texto;
    }

    public int pedirNumero(String mensaje, Scanner sc) {
        System.out.print(mensaje);
        int numero = -1;
        if (sc.hasNextInt()) {
            numero = sc.nextInt();
            sc.nextLine(); 
        } else {
            sc.nextLine(); 
        }
        return numero;
    }

    public void mostrarCatalogoLibros(String[] catalogo) {
        System.out.println("\n--- CATÁLOGO DE LIBROS ---");
        for (int i = 0; i < catalogo.length; i++) {
            System.out.println((i + 1) + ". " + catalogo[i]);
        }
    }

    public void imprimirHistorial(String nif, String[][] matriz, int fila, int puntos) {
        System.out.println("\n=================================================================");
        System.out.println("HISTORIAL COMPLETO DEL USUARIO: " + nif);
        System.out.println("=================================================================");
        System.out.println(String.format("%-6s | %-25s | %-12s | %-10s", "SLOT", "TÍTULO DEL LIBRO", "Nº PRÉSTAMO", "VALORACIÓN"));
        System.out.println("-----------------------------------------------------------------");

        boolean tienePrestamos = false;
        for (int i = 0; i < 5; i++) {
            int colT = 3 * i + 1;
            int colI = 3 * i + 2;
            int colV = 3 * i + 3;

            String titulo = matriz[fila][colT];
            String id = matriz[fila][colI];
            String val = matriz[fila][colV];

            if (titulo != null && !titulo.isEmpty()) {
                tienePrestamos = true;
                System.out.println(String.format("Slot %-2d | %-25s | %-12s | %-10s", (i + 1), titulo, id, val));
            }
        }

        if (!tienePrestamos) {
            System.out.println(" Este usuario no tiene ningún préstamo registrado en su cuenta.");
        }
        System.out.println("-----------------------------------------------------------------");
        System.out.println("PUNTUACIÓN TOTAL ACUMULADA: " + puntos + " puntos.");
        System.out.println("=================================================================\n");
    }
}