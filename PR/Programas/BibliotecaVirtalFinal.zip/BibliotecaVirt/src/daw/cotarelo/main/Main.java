package daw.cotarelo.main;

import daw.cotarelo.controlador.MenuController;
import daw.cotarelo.controller.ClaseController;
import daw.cotarelo.model.GestionSistema;
import daw.cotarelo.view.ClaseView;
import java.util.InputMismatchException;

/**
 *
 * @author fperez
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // CONFIGURACIÓN DEL MENÚ
        MenuController menu = new MenuController(
                "Biblioteca Virtual",
                new String[]{
                    "Registrar usuario",
                    "Realizar préstamo",
                    "Devolver libro y valorar",
                    "Ver historial del usuario",
                    "Reiniciar el sistema",
                    "Salir"
                }
        );

        // CONFIGURACIÓN CONTROLADOR(ES)-> InstitutoControlador
        GestionSistema modelo = new GestionSistema();
        ClaseView vista = new ClaseView();

        ClaseController controller = new ClaseController(vista, modelo);

        // LÓGICA DEL PROGRAMA PRINCIPAL
        int opcion = 0;
        boolean salir = false;

        do {
            try {
                opcion = menu.ejecutar();

                switch (opcion) {
                    case 1 -> { 
                        controller.registrarUsuario();
                        vista.mostrarMensaje("Usuario registrado con éxito!");
                    }
                    case 2 -> {
                        controller.prestamo();
                    }
                    case 3 -> {
                        controller.devolucion();
                    }
                    case 4 -> {
                        controller.historial();
                    }
                    case 5 -> {
                        controller.reiniciarSistema();
                    }
                    case 6 -> {
                        vista.cerrar();
                        salir = true;
                    }
                }
            } catch (IllegalArgumentException e) {
                vista.mostrarError(e.getMessage());
            } catch (InputMismatchException e) {
                vista.mostrarError("Debe introducir un numero.");
            } finally {
                vista.mostrarMensaje("");
            }
        } while (!salir);
    }
}