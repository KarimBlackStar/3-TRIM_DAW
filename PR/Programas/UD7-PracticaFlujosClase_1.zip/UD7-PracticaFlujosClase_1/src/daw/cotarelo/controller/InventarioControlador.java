package daw.cotarelo.controller;

import daw.cotarelo.model.*;
import daw.cotarelo.view.*;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Orquesta la comunicaci�n entre el modeloFichero y la vista.
 *
 * @author Programaci�n/DAW
 * @version 1.0
 */
public class InventarioControlador {

    private InventarioModelo modeloInventario;
    private FicheroModelo modeloFichero;
    private Vista vista;

    public InventarioControlador(
            InventarioModelo modeloLista,
            FicheroModelo modeloFichero,
            Vista vista) {
        this.modeloInventario = modeloLista;
        this.modeloFichero = modeloFichero;
        this.vista = vista;
    }

    // ==============================================
    // INICIALIZACI�N DE LA CARPETA DONDE ESTAR�N LOS FICHEROS DE SALIDA
    // ==============================================
    public void inicializarDirectorioSalida() {
        modeloFichero.inicializarDirectorio(); // El controlador habla con el modelo
    }

    // ==============================================
    // CARGA DE DATOS
    // ==============================================
    /**
     * Carga los productos desde un fichero CSV al inventario.
     * <p>
     * Delega la lectura y el parseo del fichero en {@link FicheroModelo}, y
     * a�ade cada {@link Producto} obtenido al {@link InventarioModelo}. Si se
     * produce un error de E/S, se notifica al usuario a trav�s de la vista sin
     * propagar la excepci�n.
     * </p>
     *
     * @param ruta ruta absoluta o relativa al fichero CSV que se desea cargar
     * @throws java.io.IOException
     */
    public void cargarDesdeArchivo(String ruta) throws IOException {
        //Carga el conteido del archivo csv en una lista
        List<Producto> productos = modeloFichero.cargarDesdeArchivo(ruta);
        for (Producto p : productos) {
            modeloInventario.agregarProducto(p);
        }
    }

    // ==============================================
    // CONSULTAS � MOSTRAR POR PANTALLA
    // ==============================================
    /**
     * Muestra por pantalla todos los productos del inventario.
     *
     * <p>
     * Recorre el {@code HashMap} e imprime cada entrada con el formato
     * {@code clave -- toString()}. Si el inventario est� vac�o, informa al
     * usuario con un mensaje claro.</p>
     */
    public void mostrarTodos() {
        if (!modeloInventario.getInventario().isEmpty()) {
            for (Map.Entry<Integer, Producto> entrada : modeloInventario.getInventario().entrySet()) {
                vista.mostrarMensaje(entrada.getKey() + "--" + entrada.getValue());
            }
        } else {
            vista.mostrarMensaje("El inventario est� vac�o.");
        }
    }

}
