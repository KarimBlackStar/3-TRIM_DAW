package daw.cotarelo.model;

/**
 *
 * @author M�dulo Programaci�n 1� DAW
 */
public interface IAlmacenable {
    String toCsvLine(); // Convierte el objeto a l�nea CSV 
    int getId(); // Devuelve el identificador �nico
}
