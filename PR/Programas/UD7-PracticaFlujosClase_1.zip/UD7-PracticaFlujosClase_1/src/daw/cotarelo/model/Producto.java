package daw.cotarelo.model;

/**
 * Representa un producto espec�fico dentro del inventario de hardware.
 * Esta clase extiende de {@link EntidadBase} para heredar los atributos comunes
 * e implementa los m�todos de la interfaz {@link IAlmacenable} para permitir
 * su exportaci�n a ficheros CSV
 * 
 * @author M�dulo Programaci�n 1� DAW
 * @version 1.0
 */
public class Producto extends EntidadBase {

    private String categoria;
    private String nombre;
    private double precio;
    private int stock;

    /**
     * Constructor completo para la clase Producto.
     * 
     * @param id Identificador �nico del producto
     * @param nombre Nombre descriptivo del producto
     * @param categoria Categor�a a la que pertenece (ej. Perif�ricos, Audio)
     * @param precio Valor unitario del producto
     * @param stock Cantidad de unidades disponibles en almac�n
     */
    public Producto(int id, String nombre, String categoria, double precio, int stock) {
        // Llamada obligatoria al constructor de la clase padre (EntidadBase)
        // para inicializar los atributos protegidos id y nombre
        super(id, nombre);
        this.categoria = categoria;
        this.precio = precio;
        this.stock = stock;
    }
    
    /**
     * Obtiene el nombre del producto.
     * @return String con el nombre
     */
    public String getNombre() {
        return nombre;
    }
    
    
    /**
     * Obtiene la categor�a del producto.
     * @return String con la categor�a
     */
    public String getCategoria() { 
        return categoria; 
    }

    /**
     * Obtiene el precio actual del producto.
     * @return double con el precio
     */
    public double getPrecio() { 
        return precio; 
    }

    /**
     * Obtiene el n�mero de unidades en stock.
     * @return int con la cantidad disponible
     */
    public int getStock() { 
        return stock; 
    }

    /**
     * Convierte el objeto en una l�nea de texto con formato CSV.
     * Utiliza la coma (,) como separador seg�n los requisitos del proyecto
     * 
     * @return Una cadena de texto con los campos: id, nombre, categoria, precio, stock
     */
    @Override
    public String toCsvLine() {
        // Concatenamos los atributos propios y los heredados de EntidadBase
        return id + "," + nombre + "," + categoria + "," + precio + "," + stock;
    }

    /**
     * Genera una representaci�n visual del producto formateada para consola.
     * Utiliza String.format para alinear las columnas y facilitar la lectura.
     * 
     * @return Cadena formateada con el ID, nombre (30 carac.), categor�a, precio y stock.
     */
    @Override
    public String toString() {
        // %-30s: Reserva 30 espacios para el nombre, alineado a la izquierda.
        // %8.2f: Reserva 8 espacios para el precio con 2 decimales.
        return String.format("[%d] %-30s | %-15s | %8.2f� | stock: %d",
                             id, nombre, categoria, precio, stock);
    }
}