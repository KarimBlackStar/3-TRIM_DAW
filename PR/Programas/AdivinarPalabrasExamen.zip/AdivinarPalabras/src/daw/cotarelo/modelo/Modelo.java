package daw.cotarelo.modelo;

import java.util.Random;

public class Modelo {

    // Listado de las 10 palabras informáticas del juego
    private static final String[] PALABRAS = {
        "JAVA", "PYTHON", "JAVASCRIPT", "HTML", "CSS",
        "PHP", "SQL", "RUBY", "SWIFT", "KOTLIN"
    };

    private String dniRegistrado = "";

    // Array de estadísticas: [0] partidas jugadas, [1] ganadas, [2] perdidas
    private int[] estadisticas = new int[3];
    private int puntosTotales = 0;

    // --- GETTERS ---
    public String getDniRegistrado() {
        return this.dniRegistrado;
    }

    public int[] getEstadisticas() {
        return this.estadisticas;
    }

    public int getPuntosTotales() {
        return this.puntosTotales;
    }

    // Comprueba si el DNI cumple con el patrón de 8 números y 1 letra
    public boolean validarFormatoDni(String dni) {
        boolean esValido = false;
        if (dni.matches("^\\d{8}[A-Z]$")) {
            esValido = true;
        }
        return esValido;
    }

    // Guarda el DNI en el sistema
    public void registrarDni(String dni) {
        this.dniRegistrado = dni;
    }

    // Elige una palabra al azar usando la clase Random
    public String obtenerPalabraAleatoria() {
        Random rd = new Random();
        int indiceAleatorio = rd.nextInt(PALABRAS.length);
        String palabraSeleccionada = PALABRAS[indiceAleatorio];

        return palabraSeleccionada;
    }

    // Actualiza los contadores de partidas y calcula los puntos según los intentos
    public void actualizarResultados(boolean haGanado, int intentos) {
        estadisticas[0]++; // Incrementamos partidas jugadas

        if (haGanado) {
            estadisticas[1]++; // Incrementamos ganadas
            // Si gana en los 3 primeros intentos suma 10 puntos, si no suma 5
            if (intentos <= 3) {
                puntosTotales += 10;
            } else {
                puntosTotales += 5;
            }
        } else {
            estadisticas[2]++; // Incrementamos perdidas
            puntosTotales -= 5; // Restamos 5 puntos por perder
        }
    }

    // Restablece todas las variables y marcadores a cero
    public void reiniciarValores() {
        dniRegistrado = "";
        puntosTotales = 0;
        for (int i = 0; i < estadisticas.length; i++) {
            estadisticas[i] = 0;
        }
    }
}
