package daw.cotarelo.main;

import daw.cotarelo.controlador.Controlador;
import daw.cotarelo.vista.Vista;
import java.util.InputMismatchException;
import daw.cotarelo.modelo.Modelo;

public class Main {

    public static void main(String[] args) {
        Modelo modelo = new Modelo();
        Vista vista = new Vista();
        Controlador controlador = new Controlador(vista, modelo);

        java.util.Scanner miScanner = new java.util.Scanner(System.in);
        int opcion = 0;
        boolean salir = false;

        do {
            try {
                vista.mostrarMenu();
                if (miScanner.hasNextInt()) {
                    opcion = miScanner.nextInt();
                    miScanner.nextLine(); // Limpiamos buffer
                } else {
                    miScanner.nextLine(); // Limpiamos caracteres incorrectos
                    throw new InputMismatchException();
                }

                switch (opcion) {
                    case 1:
                        controlador.procesarRegistro();
                        break; // Break Estricto
                    case 2:
                        controlador.procesarPartida();
                        break; // Break Estricto
                    case 3:
                        controlador.mostrarEstadisticas();
                        break; // Break Estricto
                    case 4:
                        controlador.reiniciarJuego();
                        break; // Break Estricto
                    case 5:
                        vista.mostrarMensaje("¡Esperamos que hayas disfrutado del juego!\n¡Hasta la próxima!");
                        salir = true;
                        break; // Break Estricto
                    default:
                        vista.mostrarError("ERROR: Opción no válida. Introduce un número del 1 al 5.");
                        break; // Break Estricto
                }
            } catch (InputMismatchException e) {
                vista.mostrarError("ERROR: ¡Solamente se aceptan números enteros para elegir la opción!");
            }
        } while (!salir);

        miScanner.close();
    }
}
