package daw.cotarelo.vista;

import java.util.Scanner;

public class Vista {

    // Muestra el menú de opciones principal
    public void mostrarMenu() {
        System.out.println("=== Menú Principal ===");
        System.out.println("1. Registrarse (Obligatorio para jugar)");
        System.out.println("2. Jugar partida");
        System.out.println("3. Ver estadísticas");
        System.out.println("4. Reiniciar el juego");
        System.out.println("5. Salir del programa");
        System.out.print("Escoge una opción: ");
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    public void mostrarError(String mensaje) {
        System.err.println(mensaje);
    }

    // Pide un texto por consola limpiando espacios
    public String pedirTexto(String mensaje, Scanner sc) {
        System.out.print(mensaje);
        String texto = sc.nextLine();
        return texto;
    }

    // Lee un número entero controlando los fallos de buffer
    public int pedirNumero(String mensaje, Scanner sc) {
        System.out.print(mensaje);
        int numero = -1;
        if (sc.hasNextInt()) {
            numero = sc.nextInt();
            sc.nextLine(); // Limpiamos el buffer
        } else {
            sc.nextLine(); // Limpiamos la entrada errónea
        }
        return numero;
    }

    // Imprime las estadísticas formateadas
    public void imprimirEstadisticas(int[] rondas, int puntos) {
        System.out.println("\n=================================");
        System.out.println("    ESTADÍSTICAS DEL JUGADOR     ");
        System.out.println("=================================");
        System.out.println("Partidas Jugadas: " + rondas[0]);
        System.out.println("Partidas Ganadas: " + rondas[1]);
        System.out.println("Partidas Perdidas: " + rondas[2]);
        System.out.println("Puntos Totales: " + puntos);
        System.out.println("=================================\n");
    }
}
