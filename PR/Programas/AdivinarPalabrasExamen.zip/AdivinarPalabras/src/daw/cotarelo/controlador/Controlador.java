package daw.cotarelo.controlador;

import daw.cotarelo.vista.Vista;
import java.util.Scanner;
import daw.cotarelo.modelo.Modelo;

public class Controlador {

    private Vista vista;
    private Modelo modelo;
    private Scanner sc;

    public Controlador(Vista vista, Modelo modelo) {
        this.vista = vista;
        this.modelo = modelo;
        this.sc = new Scanner(System.in);
    }

    // Solicita y registra el DNI atrapando posibles campos vacíos o formatos erróneos
    public void procesarRegistro() {
        try {
            String dni = vista.pedirTexto("Introduce tu DNI (8 números y una letra mayúscula): ", sc);
            dni = dni.trim();

            if (dni.isEmpty()) {
                throw new IllegalArgumentException("ERROR: El campo del DNI no puede estar vacío.");
            }

            if (!modelo.validarFormatoDni(dni)) {
                throw new IllegalArgumentException("ERROR: El formato del DNI es incorrecto (Ej: 12345678A).");
            }

            modelo.registrarDni(dni);
            vista.mostrarMensaje("¡Registro realizado con éxito! Ya puedes jugar.");

        } catch (IllegalArgumentException e) {
            vista.mostrarError(e.getMessage());
        }
    }

    // Controla todo el desarrollo de la partida pidiendo login y controlando los intentos
    public void procesarPartida() {
        try {
            String dniRegistro = modelo.getDniRegistrado();

            // Verificamos si hay alguien registrado
            if (dniRegistro == null || dniRegistro.isEmpty()) {
                throw new IllegalArgumentException("ERROR: Para poder jugar, debe haberse registrado previamente.");
            }

            // Simulación de Login obligatorio antes de empezar
            String dniLogin = vista.pedirTexto("Identifícate introduciendo tu DNI: ", sc).trim();
            if (!dniLogin.equals(dniRegistro)) {
                throw new IllegalArgumentException("ERROR: El DNI introducido no coincide con el registrado.");
            }

            vista.mostrarMensaje("\n¡Inicio de sesión correcto! Generando palabra secreta...");

            String repetir = "S";
            while (repetir.equalsIgnoreCase("S")) {
                desarrollarRonda();

                // Forzamos el control para volver a jugar
                String entrada = "";
                do {
                    entrada = vista.pedirTexto("¿Quieres volver a jugar otra partida? (S/N): ", sc).trim().toUpperCase();
                } while (!entrada.equals("S") && !entrada.equals("N"));

                repetir = entrada;
            }

        } catch (IllegalArgumentException e) {
            vista.mostrarError(e.getMessage());
        }
    }

    // Lógica interna de los 7 intentos y pistas dinámicas
    private void desarrollarRonda() {
        String palabraSecreta = modelo.obtenerPalabraAleatoria();
        int intentosMaximos = 7;
        int intentoActual = 1;
        boolean acertado = false;

        vista.mostrarMensaje("\n=== EMPIEZA EL JUEGO ===");
        vista.mostrarMensaje("La palabra contiene " + palabraSecreta.length() + " letras.");
        vista.mostrarMensaje("Pista inicial: Empieza por la letra '" + palabraSecreta.charAt(0) + "'.");

        while (intentoActual <= intentosMaximos && !acertado) {
            try {
                vista.mostrarMensaje("\nIntento " + intentoActual + " de " + intentosMaximos);
                String suposicion = vista.pedirTexto("¿Qué palabra crees que es?: ", sc).trim().toUpperCase();

                if (suposicion.isEmpty()) {
                    throw new IllegalArgumentException("ERROR: No has escrito nada. Pierdes el intento.");
                }

                if (suposicion.equals(palabraSecreta)) {
                    vista.mostrarMensaje("¡ENHORABUENA! ¡HAS ACERTADO!");
                    acertado = true;
                } else {
                    vista.mostrarMensaje("¡Palabra incorrecta!");

                    // Pista mejorada a partir del intento 4 (Muestra la última letra)
                    if (intentoActual >= 4 && intentoActual < intentosMaximos) {
                        int ultimaPosicion = palabraSecreta.length() - 1;
                        vista.mostrarMensaje("[PISTA EXTRA]: Además, la palabra termina por '" + palabraSecreta.charAt(ultimaPosicion) + "'.");
                    }
                    intentoActual++;
                }
            } catch (IllegalArgumentException e) {
                vista.mostrarError(e.getMessage());
                intentoActual++; // Suma intento igualmente por dejarlo vacío
            }
        }

        // Mandamos los resultados al modelo para actualizar marcadores y puntos
        modelo.actualizarResultados(acertado, intentoActual);

        if (!acertado) {
            vista.mostrarMensaje("\nUna lástima... Te has quedado sin intentos.");
            vista.mostrarMensaje("La palabra oculta era: " + palabraSecreta);
        }
    }

    // Muestra las estadísticas consultando al modelo
    public void mostrarEstadisticas() {
        vista.imprimirEstadisticas(modelo.getEstadisticas(), modelo.getPuntosTotales());
    }

    // Ejecuta el reseteo de los valores
    public void reiniciarJuego() {
        modelo.reiniciarValores();
        vista.mostrarMensaje("¡Los valores y marcadores se han restablecido a cero!");
    }
}
