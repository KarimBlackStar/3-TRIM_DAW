package daw.cotarelo.main;

import java.sql.*;
import daw.cotarelo.bbdd.DatabasesSetUp;
import daw.cotarelo.controlador.MenuController;
import daw.cotarelo.controller.ClaseController;
import daw.cotarelo.model.Modelo;
import daw.cotarelo.view.ClaseView;
import java.util.InputMismatchException;

/**
 *
 * @author fperez
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // CONFIGURACIÓN DEL MENÚ
        MenuController menu = new MenuController(
                "Gestión de BBDD",
                new String[]{
                    "Ver registro",
                    "Agregar registro",
                    "Borrar registro",
                    "Modificar registro",
                    "Filtrar por NOMBRE",
                    "Filtrar por EDAD",
                    "Filtrar por TIPO",
                    "Filtrar por ESPECIALIDAD",
                    "Salir"
                }
        );
        //ES VITAL PONER LAS BBDD EN UN TRY-CATCH, sino NO COMPILA
        try {
            DatabasesSetUp.crearBaseDatos();
            DatabasesSetUp.crearTablaComponentes();
            DatabasesSetUp.insertarDatosInicialesSiEstaVacia();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // CONFIGURACIÓN CONTROLADOR(ES)-> InstitutoControlador
        Modelo modelo = new Modelo();
        ClaseView vista = new ClaseView();

        ClaseController controller = new ClaseController(vista, modelo);

        // LÓGICA DEL PROGRAMA PRINCIPAL
        int opcion = 0;
        boolean salir = false;

        do {
            try {
                opcion = menu.ejecutar();

                switch (opcion) {
                    case 1 -> { // introducir docente
                        verBaseDatos();
                    }
                    case 2 -> {
                        //controller.agregarRegistro();
                    }
                    case 3 -> {
                        //controller.borrarRegistro();
                    }
                    case 4 -> {
                        // controller.modificarRegistro();
                    }
                    case 5 -> {
                        //controller.filtrarNombre();
                    }
                    case 6 -> {
                        //controller.filtrarEdad();
                    }
                    case 7 -> {
                        //controller.filtrarTipo();
                    }
                    case 8 -> {
                        //controller.filtrarEspecialidad();
                    }
                    case 9 -> {
                        vista.cerrar();
                        menu.salirDelMenu();
                    }
                }
            } catch (IllegalArgumentException e) {
                vista.mostrarError(e.getMessage());
            } catch (InputMismatchException e) {
                vista.mostrarError("Debe introducir un numero.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                vista.mostrarMensaje("");
            }
        } while (!salir);
    }

    public static void verBaseDatos() throws SQLException {
        try (Connection con = DatabasesSetUp.getConnection(); Statement sentencia = con.createStatement(); ResultSet resultado = sentencia.executeQuery("SELECT * FROM componentes")) {

            while (resultado.next()) {
                String nombre = resultado.getString("Nombre");
                int edad = resultado.getInt("Edad");
                String tipo = resultado.getString("Tipo");
                String especialidad_posicion = resultado.getString("Especialidad_posicion");
                int experiencia_dorsal = resultado.getInt("experiencia_dorsal");
                System.out.println(nombre + " - " + edad + " - " + tipo + " - " 
                + especialidad_posicion + " - " + experiencia_dorsal + "");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
