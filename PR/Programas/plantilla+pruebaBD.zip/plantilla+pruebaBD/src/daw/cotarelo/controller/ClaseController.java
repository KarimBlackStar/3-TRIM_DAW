package daw.cotarelo.controller;

import daw.cotarelo.bbdd.DatabasesSetUp;
import daw.cotarelo.model.Modelo;
import daw.cotarelo.view.ClaseView;

/**
 *
 * @author fperez
 */
public class ClaseController {
    
    private ClaseView vista;
    private Modelo modelo;

    /**
     *
     * @param vista
     * @param modelo
     */
    public ClaseController(ClaseView vista, Modelo modelo) {
        this.vista = vista;
        this.modelo = modelo;
    }

    /**
     *
     */
    public void insertarElemento() {
        // declaración de variables
        
        do {
            // petición de datos
            // agregar el elemento a la colección
            
            // determinar la validez de los datos si es necesario o si se 
            // desean introducir más datos (si se permiten varias inserciones)
        } while (true /*sustituir por la condicion correspondiente*/);
    }

    /**
     *
     */
    public void buscarElemento() {
        // pedir el dato necesario
        // buscar el elemento
        // mostrar Elemento
    }

    /**
     * Plantilla
     */
    public void listarElementos() {
        // formatearlo como sea necesario
        for (Object o : modelo.getLista()) {
            vista.mostrarMensaje(o.toString() + "\n");
        }
    }

    /**
     *
     */
    public void eliminarElemento() {
        // pedir dato
        // usar método eliminarElemento
    }

}
