package daw.cotarelo.bbdd;

import java.sql.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author usuario
 */
public class DatabasesSetUp {

    private static final String BBDD_URL = "jdbc:mysql://localhost:3306/";
    private static final String BBDD_NAME = "clubdeportivo";
    private static final String BBDD_URL_WITH_BBDD = BBDD_URL + BBDD_NAME;
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    /**
     * Conexi�n a la base de datos espec�fica (para operaciones normales)
     * @throws java.sql.SQLException
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(BBDD_URL_WITH_BBDD, USER, PASSWORD);
    }

    /**
     * Crea la base de datos 'cubdeportivo' si no existe.
     */
    public static void crearBaseDatos() throws SQLException {
        String sql = "CREATE DATABASE IF NOT EXISTS " + BBDD_NAME;

        try (Connection con = DriverManager.getConnection(BBDD_URL, USER, PASSWORD); Statement pstmt = con.createStatement()) {
            pstmt.executeUpdate(sql);
            System.out.println("Base de datos " + BBDD_NAME + "verificada/creada con éxito!");
        }

    }

    /**
     * Crea la tabla 'Componentes' con los atributos especificados si no existe.
     *
     * @throws java.sql.SQLException
     */
    public static void crearTablaComponentes() throws SQLException {
        //En Java, una cadena entre "..." no puede contener saltos de l�nea reales. 
        //Los text blocks (""") resuelven esto permitiendo escribir SQL.
        String sql = """
                 CREATE TABLE IF NOT EXISTS componentes (
                 id INT AUTO_INCREMENT PRIMARY KEY,
                 nombre VARCHAR(100) NOT NULL,
                 edad INT NOT NULL,
                 tipo ENUM('ENTRENADOR', 'JUGADOR') NOT NULL,
                 especialidad_posicion VARCHAR(50),
                 experiencia_dorsal INT
                 );
                 """;
        /*ES IMPORTANTE CONSERVAR LOS NOMBRES DE LAS TABLAS EN CASO DE QUE TENGAMOS 
         IF NOT EXISTS, es decir, si es especialidad_posicion, debo ponerlo así tambien
        posteriormente, mejor prevenir que curar*/
        
        // Try-with-resources para asegurar el cierre de la conexi�n al servidor 
        try (Connection conn = DatabasesSetUp.getConnection(); Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(sql);
            System.out.println("Tabla 'componentes' verificada.");
        }
    }
    /**
     * Inserta datos inicialies en la tabla componenetes de la base de datos
     * club deportivo Si ya están insertados no hace nada
     */
    public static void insertarDatosInicialesSiEstaVacia() {
        String sqlCheck = "SELECT COUNT(*) FROM componentes";
        String sqlInsert = "INSERT INTO componentes "
                + "(nombre, edad, tipo, especialidad_posicion, experiencia_dorsal) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabasesSetUp.getConnection()) {
            // Desactivamos autocommit para controlar la transacción manualmente
            conn.setAutoCommit(false);
            try (
                    Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sqlCheck)) {
                if (rs.next() && rs.getInt(1) == 0) {
                    System.out.println("La tabla está vacía. Insertando datos iniciales...");
                    Object[][] datos = {
                        {"Sarina Wiegman", 54, "ENTRENADOR", "Estrategia competitiva", 20},
                        {"Pep Guardiola", 53, "ENTRENADOR", "Posesión", 25},
                        {"Kylian Mbappé", 25, "JUGADOR", "Delantero", 9},
                        {"Lamine Yamal", 16, "JUGADOR", "Extremo", 19},
                        {"Sonia Bompastor", 43, "ENTRENADOR", "Desarrollo de talento", 15},
                        {"Aitana Bonmatí", 26, "JUGADOR", "Centrocampista", 14}
                    };
                    try (PreparedStatement pstmt = conn.prepareStatement(sqlInsert)) {
                        for (Object[] fila : datos) {
                            pstmt.setString(1, (String) fila[0]);
                            pstmt.setInt(2, (Integer) fila[1]);
                            pstmt.setString(3, (String) fila[2]);
                            pstmt.setString(4, (String) fila[3]);
                            pstmt.setInt(5, (Integer) fila[4]);

                            pstmt.addBatch();
                        }
                        pstmt.executeBatch();

                        // Confirmamos TODAS las inserciones
                        conn.commit();
                        System.out.println("¡Datos insertados correctamente!");
                    }
                } else {
                    System.out.println("La tabla ya contiene registros.");
                }
            } catch (SQLException e) {
                // Si algo falla, revertimos TODO
                conn.rollback();

                System.err.println("Error durante la inserción. Rollback realizado.");
                throw e;
            }

        } catch (SQLException e) {
            System.err.println("Error BD: " + e.getMessage());
        }
    }
}
